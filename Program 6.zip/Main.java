import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.io.IOException;
import java.io.BufferedReader;
import java.io.BufferedWriter;


public class Main {
    static void bubbleSort(int[] arr) {
        int n = arr.length;
        int temp = 0;
        for (int i = 0; i < n; i++) {
            for (int j = 1; j < (n - i); j++) {
                if (arr[j - 1] > arr[j]) {
                    temp = arr[j - 1];
                    arr[j - 1] = arr[j];
                    arr[j] = temp;
                }
            }
        }
    }

    static void selectionSort(int[] arr) {
        int size = arr.length;
        for (int i = 0; i < size - 1; i++) {
            int minimum = i;
            for (int j = i + 1; j < size; j++) {
                if (arr[j] < arr[minimum]) {
                    minimum = j;
                }
            }
            if (minimum != i) {
                int temp = arr[i];
                arr[i]= arr[minimum];
                arr[minimum] = temp;
            }
        }

    }
    static void bubbleSort(String[] arr) {
        int n = arr.length;
        for (int i = 0; i < n; i++) {
            for (int j = 1; j < (n - i-1); j++) {
                if (arr[j].compareTo(arr[j+1])>0) {
                    String temp = arr[j];
                    arr[j] = arr[j+1];
                    arr[j + 1 ] = temp;
                }
            }
        }
    }

    static void selectionSort(String[] arr) {
        int size = arr.length;
        for (int i = 0; i < size - 1; i++) {
            int minimum = i;
            for (int j = i + 1; j < size; j++) {
                if (arr[j].compareTo(arr[minimum])<0) {
                    minimum = j;
                }
            }
            if (minimum != i) {
                String temp = arr[i];
                arr[i]= arr[minimum];
                arr[minimum] = temp;
            }
        }

    }

    public static void main(String[] args) {
        int[] intArrBub = new int[20000];
        int[] intArrSort = new int[20000];
        ArrayList<Integer> intArrayList = new ArrayList<>();
        try (BufferedReader input = new BufferedReader(new FileReader("NumbersInFile.txt"))) {
            String line;
            int index = 0;
            while ((line = input.readLine()) != null && index < 20000) {
                int num = Integer.parseInt(line);
                intArrBub[index] = num;
                intArrSort[index] = num;
                intArrayList.add(num);
                index++;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        long startTime;
        long endTime;

        startTime = System.nanoTime();
        bubbleSort(intArrBub);
        endTime = System.nanoTime();
        long intBubSortTotal = endTime - startTime;

        startTime = System.nanoTime();
        selectionSort(intArrSort);
        endTime = System.nanoTime();
        long intSelSortTotal = endTime - startTime;

        String [] stringArrBub = new String[10000];
        String[] stringArrSort = new String[10000];
        ArrayList<String> stringArrayList = new ArrayList<>();
        try (BufferedReader input = new BufferedReader(new FileReader("StringsInFile.txt"))) {
            String line;
            int index = 0;
            while ((line = input.readLine()) != null && index < 20000) {
                String stringValue = line;
                stringArrBub[index] = stringValue;
                stringArrSort[index] = stringValue;
                stringArrayList.add(stringValue);
                index++;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        long startTimeString;
        long endTimeString;

        startTimeString = System.nanoTime();
        bubbleSort(stringArrBub);
        endTimeString = System.nanoTime();
        long stringBubSortTotal = endTimeString - startTimeString;

        startTimeString = System.nanoTime();
        selectionSort(stringArrSort);
        endTimeString = System.nanoTime();
        long stringSelSortTotal = endTimeString - startTimeString;

        long startTimeCol;
        long endTimeCol;

        startTimeCol = System.nanoTime();
        Collections.sort (stringArrayList);
        endTimeCol= System.nanoTime();
        long colSortTime = endTimeCol - startTimeCol;

        try (FileWriter output = new FileWriter("results.txt")){
            output.write ("Array Length: "+ intArrayList.size()+ '\n');
            output.write ("BubbleSort Time: " + String.valueOf(intBubSortTotal) + "\n");
            output.write ("Array Length: "+ intArrayList.size()+ '\n');
            output.write ("SelectionSort Time: " + String.valueOf(intSelSortTotal)+ "\n");
            output.write ("Array Length: "+ stringArrayList.size()+ '\n');
            output.write ("BubbleSort Time: " +String.valueOf(stringBubSortTotal)+ "\n");
            output.write ("Array Length: "+ stringArrayList.size()+ '\n');
            output.write ("SelectionSort Time: " + String.valueOf(stringSelSortTotal)+" \n");
            output.write ("Array Length: "+ intArrayList.size()+ '\n');
            output.write("Collection Time: " + String.valueOf(colSortTime)+ "\n");
            }
        catch (IOException e){
            e.printStackTrace();
        }
    }
}