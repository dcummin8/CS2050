// Dawson Cummings

import java.io.BufferedWriter;
import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.FileReader;
import java.io.IOException;

class Node{
    String key;
    Node left , right;
    public Node(String item){
        key = item;
        left = right = null;
    }
}
class BST {
    public Node createNewNode(String key) {
        Node a = new Node(key);
        a.left = null;
        a.right = null;
        return a;
    }

    public Node insert(Node root, String key) {
        if (root == null) {
            return createNewNode(key);
        }
        int compare = key.toLowerCase().compareTo(root.key.toLowerCase());
        if (compare < 0) {
            root.left = insert(root.left, key);
        }
        if (compare > 0) {
            root.right = insert(root.right, key);
        }
        return root;
    }

    public void insertWord(String word, Node root) {
        word = word.toLowerCase().replaceAll("[^a-z]", "");
        if (!word.isEmpty()) {
            root = insert(root, word);
        }
    }

    public void getTheTree(String file, Node root) {
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] words = line.split("\\s+");
                for (String word : words) {
                    insertWord(word, root);
                }
            }
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    public int countNodes(Node root) {
        if (root == null) {
            return 0;
        }
        return 1 + countNodes(root.left) + countNodes(root.right);
    }

    public int heightOfTree(Node root) {
        if (root == null) {
            return 0;
        }
        int heightLeft = heightOfTree(root.left);
        int heightRight = heightOfTree(root.right);
        return 1 + Math.max(heightLeft, heightRight);
    }

    public void analysisToFile(String filename, Node root) throws IOException {
        try (BufferedWriter bw = new BufferedWriter((new FileWriter(filename)))) {
            int nodeCount = countNodes(root);
            int treeHeight = heightOfTree(root);
            int finNodeCount = (int) Math.pow(2, treeHeight) - 1;
            bw.write("Amount of Nodes: " + nodeCount + '\n');
            bw.write("Tree Height: " + treeHeight + '\n');
            bw.write("Max Nodes: " + finNodeCount + '\n');
        }
    }

    public static void main(String[] args) {
        BST bst = new BST();
        Node root = null;
        try {
            root = bst.createNewNode(" ");
            bst.getTheTree("dracula.txt",root);
            bst.analysisToFile("analysis.txt",root);


        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
}