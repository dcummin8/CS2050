import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.BufferedReader;
import java.io.FileReader;

public class Program4 {

    private static boolean isOperator(char c) {
        return c == '+' || c == '-' || c == '*' || c == '/' || c == '^' || c == '%';
    }

    private static int precedence(char a) {
        switch (a) {
            case '^':
                return 3;
            case '*':
            case '/':
            case '%':
                return 2;
            case '+':
            case '-':
                return 1;
            default:
                return 0;
        }
    }

    public static String infixToPostfixLL(String expression) {
        StringBuilder postfix = new StringBuilder();
        MyLinkedStack StackLL = new MyLinkedStack(32);

        for (char ch : expression.toCharArray()) {
            if (Character.isDigit(ch) || ch == '.') {
                postfix.append(ch);
            } else if (isOperator(ch)) {
                while (!StackLL.empty() && precedence(ch) <= precedence(StackLL.peek())) {
                    postfix.append(" ").append(StackLL.pop());
                }
                StackLL.push(ch);
            }
        }

        while (!StackLL.empty()) {
            postfix.append(" ").append(StackLL.pop());
        }

        return postfix.toString().trim();
    }

    public static void main(String[] args) {
        try (BufferedReader input = new BufferedReader(new FileReader("Program3.txt"));
             BufferedWriter output = new BufferedWriter(new FileWriter("Program3.out"))) {
            String line;
            while ((line = input.readLine()) != null) {
                String postfix = infixToPostfixLL(line);
                System.out.println("infix " + line);
                System.out.println("postfix " + postfix);

                output.write(line + " ----> " + postfix + "\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}