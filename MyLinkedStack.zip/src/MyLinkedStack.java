//Dawson Cummings
//Program 3
// implementing stack
import java.util.EmptyStackException;
class Node {
    char data;
    Node next;

    public Node(char data) {
        this.data = data;
        this.next = null;
    }
}
class MyLinkedStack {
    Node top;
    int size;
    public char[] items;

    public MyLinkedStack(int size) {
        this.size = 0;
        top = null;
        items = new char[size];
    }

    public void push(char data) {
        Node newNode = new Node(data);
        newNode.next = top;
        top = newNode;
        size++;
    }

    public char pop() {
        if (empty()) {
            System.out.println("Stack is empty");
            return '\0'; // Return a default value for char
        }
        char poppedData = top.data;
        size--;
        top = top.next; // Move the top pointer
        return poppedData;
    }

    public int size() {
        return size;
    }

    public boolean empty() {
        return size == 0;
    }

    public char peek() {
        if (empty()) {
            System.out.println("Stack is Empty!");
            return '\0';
        }
        return top.data;
    }
}


