
public class Album {
        String title;
        String performer;
        String genre;
        int numSongs;
        public Album(String title, String performer, String genre, int numSongs) {
                this.title = title;
                this.performer = performer;
                this.genre = genre;
                this.numSongs = numSongs;
        }
        public String toString(){
                return title + " " + performer  +" " + genre + " " + numSongs;
        }
        boolean isLong(){
                if(numSongs > 50 )
                        return true;
                else
                        return false;
        }
        public String getTitle(){
                return title;
        }

        public String getPerformer() {
                return performer;
        }
         public String getGenre(){
                return genre;
        }

        public int getNumSongs(){
                return numSongs;
        }
        public void setTitle(String newTitle){
                this.title = newTitle;
        }
        public void setPerformer(String newPerformer) {
                this.performer= newPerformer;
        }
        public void setGenre(String newGenre){
                this.genre= newGenre;
        }
        public void setNumSongs(int newNumSongs){
                this.numSongs = newNumSongs;
        }
}
