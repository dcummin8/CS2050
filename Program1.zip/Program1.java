import java.util.Scanner;
// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.

public class Program1 {
    public static void main(String[] args) {
        // Press Alt+Enter with your caret at the highlighted text to see how
        // IntelliJ IDEA suggests fixing it.
        Scanner usr = new Scanner(System.in);
        Album[] albums = new Album[3];
        String easyListening = "easy listening";
        System.out.println("Welcome! I will ask you for 3 albums one at a time based on 4 categories. I will ask you for them one at a time");
        for (int i = 0; i < 3; i++) {
            System.out.println("Give me a Title");
            String title = usr.nextLine();
            System.out.println("Give me a performer");
            String performer = usr.nextLine();
            System.out.print("Give me a Genre");
            String genre = usr.nextLine();
            System.out.print("Give me a number of songs in album");
            int numSongs = usr.nextInt();
            if (numSongs < 10) {
                numSongs = 10;
            }
            albums[i] = new Album(title, performer, genre, numSongs);
            albums[i].setTitle(title);
            albums[i].setPerformer(performer);
            albums[i].setGenre(genre);
            albums[i].setNumSongs(numSongs);
        }

        for (int i = 0; i < 3; i++) {
            System.out.println("Title: " + albums[i].getTitle());
            System.out.println("Performer: " + albums[i].getPerformer());
            System.out.println("Genre: " + albums[i].getGenre());
            System.out.println("Number of Songs: " + albums[i].getNumSongs());
            System.out.println();
        }
    }
}

